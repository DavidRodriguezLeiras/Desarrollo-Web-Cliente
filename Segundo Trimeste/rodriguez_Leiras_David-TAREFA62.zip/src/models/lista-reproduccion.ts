export class ListaReproduccion {
    _id:number;
    _nombre:string;
    _idCanciones:number[];
    _pathImagen:string;
    constructor(id:number,nombre:string, idCanciones:number[], imagen:string) {
        this._id = id;
        this._nombre = nombre;
        this._idCanciones = idCanciones;
        this._pathImagen = imagen;
    }

    get id() { return this._id; }
    get nombre() { return this._nombre; }
    get idCanciones() { return this._idCanciones; }
    get pathImagen() { return this._pathImagen; }

    anadirCancion(idCancion:number) {
        this._idCanciones.push(idCancion);
    }

    eliminarCancion(idCancion:number) {
        //Usamos filter para eliminar la cancion con el id indicado de nuestra propiedad canciones
        this._idCanciones = this._idCanciones.filter(cancion => cancion != idCancion);
    }
}
