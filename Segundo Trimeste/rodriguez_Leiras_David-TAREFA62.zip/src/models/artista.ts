export class Artista {
    _id:number;
    _nombre:string; 
    _idCanciones:number[];
    _imagen:string;
    _idAlbumes:number[];
    _idGeneros:number[];
    constructor(id:number, nombre:string, idCanciones:number[],imagen:string,idAlbumes:number[],idGeneros:number[]){
        this._id = id;
        this._nombre = nombre;
        this._idCanciones = idCanciones;
        this._imagen = imagen;
        this._idAlbumes= idAlbumes;
        this._idGeneros=idGeneros;
    }

    //Getters
    get id() { return this._id; }
    get nombre() { return this._nombre; }
    get idCanciones() { return this._idCanciones; }
    get pathImagen() { return this._imagen; }
    get idAlbumes() { return this._idAlbumes; }
    get idGeneros() { return this._idGeneros; }

    //Funcion para añadir una cancion a la lista de canciones.
    anadiridCanciones(idCancion:number) { this._idCanciones.push(idCancion); }

    //Funcion para eliminar una cancion a la lista de canciones.
    eliminarCanciones(idCancion:number) { this._idCanciones=this._idCanciones.filter(cancion=> cancion!= idCancion); }

    //Funcion para añadir un album al array de id de Album
    anadirAlbum(idAlbum:number){ this._idAlbumes.push(idAlbum); }

    //Funcion para añadir un album al array de id de Album
    eliminarAlbum(idAlbum:number) { this._idAlbumes = this._idAlbumes.filter(album => album!=idAlbum); }

    //Funcion para añadir un genero al array de generos
    anadirGenero(idGenero:number) { this._idGeneros.push(idGenero); }

    //Funcion para eliminar un genero del arry de generos
    eliminarGenero(idGenero:number) { this._idGeneros = this._idGeneros.filter(genero => genero !=idGenero); }
    
}
