export class Usuario {
    _id:number;
    _nombreUsuario:string;
    _nombre:string;
    _apellidos:string;
    _email:string;
    _contrasena:string;
    _rol:string;
    _planVibe:boolean;
    _idArtista:number;
    _idListasReproduccion:number[];
    constructor(id:number,nombreUsuario:string, nombre:string,apellidos:string,email:string,contrasena:string,rol:string,planVibe:boolean = false, idArtista:number, idListas:number[]) {
        this._id = id;
        this._nombreUsuario=nombreUsuario;
        this._nombre = nombre;
        this._apellidos= apellidos;
        this._email= email;
        this._contrasena=contrasena;
        this._rol=rol;
        this._planVibe= planVibe;
        this._idArtista = idArtista;
        this._idListasReproduccion = idListas;
    }

    //Getters
    get id() { return this._id; }
    get nombreUsuario() { return this._nombreUsuario; }
    get nombre() { return this._nombre; }
    get apellidos() { return this._apellidos; }
    get email() { return this._email; }
    get contrasena() { return this._contrasena; }
    get rol() { return this._rol; }
    get planVibe() { return this._planVibe; }
    get idArtista() { return this._idArtista; }
    get idListasReproduccion() { return this._idListasReproduccion; }
    set idListasReproduccion(idLista:number[]) { this._idListasReproduccion=idLista; }
}
