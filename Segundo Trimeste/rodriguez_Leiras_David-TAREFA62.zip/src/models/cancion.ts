export class Cancion {
    _id:number;
    _titulo:string;
    _idArtista:number;
    _duracion:number;
    _genero:number;
    _pathCancion:string;
    constructor(id:number, titulo:string, idArtista:number, duracion:number,genero:number,pathCancion:string) {
        this._id = id;
        this._titulo = titulo;
        this._idArtista = idArtista;
        this._duracion = duracion;
        this._genero=genero;
        this._pathCancion=pathCancion;
        
    }

    //Getters
    get id() { return this._id; }
    get titulo() { return this._titulo; }
    get idArtista() { return this._idArtista; }
    get duracion() { return this._duracion; }
    get genero() { return this._genero; }
    get pathCancion() { return this._pathCancion; }
}
