export class Album {
    _id:number;
    _nombreAlbum:string;
    _descripcion:string;
    _fechaSalida:string;
    _idCanciones:number[];
    _pathImagen:string;
    _idGeneros:number[];

    constructor(id:number,nombreAlbum:string,descripcion:string='',fechaSalida:string='',idCanciones:number[],pathImagen:string,idGeneros:number[]){
        this._id=id;
        this._nombreAlbum=nombreAlbum;
        this._descripcion=descripcion;
        this._fechaSalida=fechaSalida;
        this._idCanciones=idCanciones;
        this._pathImagen=pathImagen;
        this._idGeneros=idGeneros;
    }

    //Getters
    get id(){ return this._id; }
    get nombreAlbum() { return this._nombreAlbum; }
    get descripcion() { return this._descripcion; }
    get fechaSalida() { return this._fechaSalida; }
    get idCanciones() { return this._idCanciones; }
    get pathImagen() { return this._pathImagen; }
    get idGeneros() { return this._idGeneros; }

    //Funcion para añadir canciones al array de canciones
    anadirCancion(idCancion:number){ this._idCanciones.push(idCancion); }

    //Funcion para eliminar canciones del array de canciones
    eliminarCancion(idCancion:number){ this._idCanciones= this._idCanciones.filter(cancion => cancion != idCancion); }

    //Funcion para añadir un genero al array de generos
    anadirGenero(idGenero:number){ this._idGeneros.push(idGenero); }

    //Funcion para eliminar un genero al arrya de generos
    eliminarGenero(idGenero:number){ this._idGeneros= this._idGeneros.filter(genero=> genero != idGenero); }

}
