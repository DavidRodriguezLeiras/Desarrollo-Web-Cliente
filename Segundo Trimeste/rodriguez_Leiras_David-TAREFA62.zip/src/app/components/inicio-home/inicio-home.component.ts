import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Artista } from '../../../models/artista';
import { ListaReproduccion } from '../../../models/lista-reproduccion';
import { Cancion } from '../../../models/cancion';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Usuario } from '../../../models/usuario';
import { Album } from '../../../models/album';
import { Genero } from '../../../models/genero';

@Component({
  selector: 'app-inicio-home',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './inicio-home.component.html',
  styleUrl: './inicio-home.component.css'
})
export class InicioHomeComponent {
  //Recibo desde el componente madre todos los recursos que necesito en este componente
  @Input() artistas:Artista[];
  @Input() listas:ListaReproduccion[];
  @Input() canciones:Cancion[];
  @Input() albumes:Album[];
  @Input() generos:Genero[];
  @Input() usuario:Usuario; //Recibo el usuario logado actualmente.

  generoSeleccionado:number=0;

  @Output() reproducirListaEmitir=new EventEmitter<[number,number]>//Emitimos el indice y id de lista de reproducir para el reproductor
  @Output() cancionListaAnadir= new EventEmitter<[number,number]>;//Envio al componente madre los id de cancion/lista y esta añada la cancion a la lista.
  @Output() artistaSeleccionado= new EventEmitter<number>;//Envio el id del artista seleccionado al componente madre para mostrar la vista de este artista
  @Output() anadirListaRep=new EventEmitter<number>;//Envio el id de la lista de reproduccion a añadir al array de listas del usuario logeado
  @Output() listaSeleccionada = new EventEmitter<number>;//Envio el id de la lista seleccionada al componente madre para mostrar la vista de dicha lista

  formAnadir:FormGroup; //Formulario para añadir una cancion a una lista
  formActivado:number|null=null;//Variable que muestra o oculta el formulario usando su id

  constructor(private form:FormBuilder){ }
  
  devolverArtista(cancion:Cancion){
    return this.artistas.find((artista)=> artista.id == cancion.id).pathImagen;
  }

  //Funcion que muestra o oculta el formulario para añadir canciones a las listas.
  mostrarForm(id:number){
    if(this.formActivado!=null){
      this.formActivado=null;
    }else {
      this.formActivado=id;
      this.formAnadir=this.form.group({
        idLista:[-1]
      });
    }
  }
  esconderForm(){
    this.formActivado=null;
  }

  /*Funciones que emiten al componente madre diferentes valores:
      -anadirCancion():el id de una cancion y de una lista para añadir dicha cancion a la lista, y despues oculta el formulario.
      -anadirLista(): el id de una lista de reproduccion para añadirla al array de listas del usuario
      -artistaSeleccion():el id del artista del que queremos mostrar su vista
      -listaSeleccion(): el id de una lista de la que queremos mostrar su vista 
  */
  anadirCancion(idCancion:number){
    this.cancionListaAnadir.emit([idCancion,this.formAnadir.value['idLista']]);
    this.mostrarForm(idCancion);
  }

  anadirLista(idLista:number){
    this.anadirListaRep.emit(idLista);
  }

  artistaSeleccion(idArtista:number){
    this.artistaSeleccionado.emit(idArtista);
  }

  listaSeleccion(idLista:number){
    this.listaSeleccionada.emit(idLista);
  }

  seleccionarGenero(idGenero:number){
    this.generoSeleccionado =idGenero;
  }

  //Funciones para filtrar en funcion del genero seleccionado
  cancionesFiltradas(idGenero:number){
    if(idGenero!=0){
      return this.canciones.filter(cancion=> cancion.genero == idGenero);
    } else {
      return this.canciones;
    }
  }
  artistasFiltrados(idGenero:number){
    if(idGenero!=0){
      return this.artistas.filter(artista=> artista.idGeneros.includes(idGenero));
    }else {
      return this.artistas;
    }
  }
  albumesFiltrados(idGenero:number){
    if(idGenero!=0){
      return this.albumes.filter(album=> album.idGeneros.includes(idGenero));
    }else {
      return this.albumes;
    }
  }

  reproducirLista(indice:number,idLista:number){
    this.reproducirListaEmitir.emit([indice,idLista]);
  }
}
