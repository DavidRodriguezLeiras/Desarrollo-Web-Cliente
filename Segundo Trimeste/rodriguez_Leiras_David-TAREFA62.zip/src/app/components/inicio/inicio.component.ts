import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { Usuario } from '../../../models/usuario';
import { CommonModule } from '@angular/common';
import { BibliotecaComponent } from "../biblioteca/biblioteca.component";
import { ListaReproduccion } from '../../../models/lista-reproduccion';
import { Cancion } from '../../../models/cancion';
import { Artista } from '../../../models/artista';
import { ListaReproduccionComponent } from "../lista-reproduccion/lista-reproduccion.component";
import { ReproductorComponent } from "../reproductor/reproductor.component";
import { VistaArtistaComponent } from "../vista-artista/vista-artista.component";
import { GestorDatosService } from '../../gestor-datos.service';
import { ServicioLoginService } from '../../servicio-login.service';
import { InicioHomeComponent } from "../inicio-home/inicio-home.component";
import { Album } from '../../../models/album';
import { Genero } from '../../../models/genero';
import { FormularioNuevoAlbumComponent } from "../formulario-nuevo-album/formulario-nuevo-album.component";


@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [HeaderComponent, CommonModule, BibliotecaComponent, ListaReproduccionComponent, ReproductorComponent, VistaArtistaComponent, InicioHomeComponent, FormularioNuevoAlbumComponent],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent implements OnInit {
  //Inicializamos los recursos que vamos a necesitar para nutrir al resto de componentes de informacion.
  usuario:Usuario;
  listas:ListaReproduccion[]=[];
  canciones:Cancion[]=[];
  artistas:Artista[]=[];
  albumes:Album[]=[];
  generos:Genero[]=[];

  //Artista perteneciente al usuario con sesion iniciada
  artista:Artista;
  
  //Booleano que oculta todos los componentes del contenedor principal cuando se pulsa el boton de "Home"
  home:boolean=true;

  //Booleano que muestra el formulario de creacion de Album
  formAlbum:boolean=false;

  //Lista a devolver al componente lista-reproduccion
  lista:ListaReproduccion|null;
  //Canciones a devolver al componente lista-reproduccion o al componente vista-artista
  cancionesLista:Cancion[]=[];
  //Artistas a devolver al componente lista-reproduccion
  artistasLista:Artista[]=[];
  //Artista a devolver al componente vista-artista
  artistaSeleccion:Artista|null;

  //Canciones que seran reproducidas
  cancionesReproductor:Cancion[]=[];
  //Indice por el que empieza a reproducir el reproductor
  indiceReproductor:number;



  constructor(private servicio:GestorDatosService , private servicioLogin:ServicioLoginService){ }

  //Hacemos suscripcion de todos los elementos que necesitamos
  ngOnInit(): void {
    this.servicio.subscribirse$('usuario')!.subscribe((usuario:Usuario)=> { this.usuario=usuario });
    this.servicio.subscribirse$('artistas')!.subscribe((artistas:Artista[])=> { this.artistas= artistas });
    this.servicio.subscribirse$('listas')!.subscribe((listas:ListaReproduccion[])=> { this.listas=listas; });
    this.servicio.subscribirse$('canciones')!.subscribe((canciones:Cancion[])=> { this.canciones=canciones });
    this.servicio.subscribirse$('albumes')!.subscribe((albums:Album[])=>{ this.albumes=albums });
    this.servicio.subscribirse$('generos')!.subscribe((genero:Genero[])=>{ this.generos=genero });
    this.servicio.subscribirse$('artista')!.subscribe((artista:Artista)=> this.artista=artista);
  }

  //Recibe un id de lista de reproduccion y la borra del array de id de listas de reproduccion del objeto usuario.
  eliminarListaUsuario(evento:number){
    this.servicio.manejarListasUsuario(this.usuario.id,evento,"delete");
  }

  //Crea una nueva lista de reproduccion y la agrega al array de id de listas de reproduccion del objeto usuario.
  crearLista(evento:string){
    this.servicio.crearLista(evento);
    this.servicio.manejarListasUsuario(this.usuario.id,this.listas.at(-1)!.id,"add");
  }

  //Añadimos una lista de reproduccion existente al array de listas asignadas al usuario a traves del servicio de gestor de datos.
  anadirLista(evento:number){
    this.servicio.manejarListasUsuario(this.usuario.id,evento,'add');
  }

  //Funcion que me permite seleccionar una lista de reproduccion y enviar toda la informacion al componente lista-reproduccion para mostrar la informacion.
  recibirSeleccion(evento:number){
    this.lista;
    this.cancionesLista=[];
    this.artistasLista=[];
    this.artistaSeleccion=null;
    this.home=false;
    this.lista=this.listas.find((listabuscar) => listabuscar.id == evento)!;
    this.lista?.idCanciones.forEach(cancion => {
      this.cancionesLista.push(this.canciones.find((cancionesBuscar) => cancionesBuscar.id == cancion)!);
    });
    this.cancionesLista.forEach(cancion => {
      this.artistasLista.push(this.artistas.find((artistaBuscar) => artistaBuscar.id == cancion.idArtista)!);
    });
  }

  //Funcion que elimina una cancion de la lista de reproduccion indicada, recoje 2 id, el id de la cancion y el id de la lista de donde se eliminara.
  eliminarCancionLista($event:[number,number]){
    this.servicio.manejarCancionesLista($event[0],$event[1],"delete");
    this.lista=this.listas.find((listaBuscar)=> listaBuscar.id == $event[1])!;
    this.recibirSeleccion($event[1]);
  }

  //Funcion que recibe un id de un objeto Artista y guarda en la variable cancionesLista los id de las canciones de dicho Artista
  recibirArtista(id:number){
    this.lista=null;
    this.home=false;
    this.cancionesLista=[];
    this.artistaSeleccion=this.artistas.find((artistaBuscar)=> artistaBuscar.id == id)!;
    this.artistaSeleccion?.idCanciones.forEach(cancion => {
      this.cancionesLista.push(this.canciones.find((cancionBuscar)=> cancionBuscar.id == cancion)!);
    });
  }

  //Funcion que recibe un array de 2 numeros desde la vista-artista un id de cancion y un id de lista, y añade dicha cancion a la lista.
  anadirCancionLista($event:number[]){
    this.servicio.manejarCancionesLista($event[0],$event[1],"add");
  }

  //Recibimos el valor booleano desde el componente header para saber si se ha pulsado el boton de home, y ocultamos todos los componentes y mostrarmos el componente home
  recibirHome($event:boolean){
    this.lista=null;
    this.artistaSeleccion=null;
    this.home=true;
  }

  //Funcion que muestra o oculta el fomulario de creacion de Album
  nuevoAlbum(){
    this.formAlbum=!this.formAlbum;
  }

  //Funcion que envia un array de canciones correspondiente al id de lista de reproduccion que recibe y 
  //tambien devuelve el indice
  reproducir($event:number[]){
    let lista= this.listas.find(list=> list.id==$event[1]);
    let canciones:Cancion[]=[];
    lista.idCanciones.forEach(idCancion => {
      canciones.push(this.canciones.find(cancion=>cancion.id==idCancion));
    });
    this.cancionesReproductor=canciones;
    this.indiceReproductor=$event[0];
  }
}

