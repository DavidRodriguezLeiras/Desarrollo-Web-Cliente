import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { Artista } from '../../../models/artista';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { GestorDatosService } from '../../gestor-datos.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-editar-artista',
  standalone: true,
  imports: [HeaderComponent, FooterComponent,ReactiveFormsModule,CommonModule,RouterLink],
  templateUrl: './editar-artista.component.html',
  styleUrl: './editar-artista.component.css'
})
export class EditarArtistaComponent implements OnInit{
  artistas:Artista[];
  artista:Artista;
  editarArtistaForm:FormGroup;

  constructor(private ruta:ActivatedRoute , private servicio:GestorDatosService,private fb:FormBuilder){
    this.editarArtistaForm=this.fb.group({
      nombreArtista:['',[Validators.required]],
    });
  }

  ngOnInit(): void {
    this.servicio.subscribirse$('artistas').subscribe((artistas:Artista[])=>{ 
      this.artistas=artistas

      //Recibimos como parametro de la ruta el id del artista que queremos modificar
      this.ruta.params.subscribe(idArtista => { 
        this.artista = this.artistas.find(artista=> artista.id == idArtista["artista"]); //Suscribimos a traves del parametro el usuario a modificar
      });
      this.campoArtista.setValue(this.artista.nombre);
    });
  }


  actualizarArtista(){
    if(this.editarArtistaForm.valid){
      let artistaCambiar =  new Artista(this.artista.id,this.campoArtista.value,this.artista.idCanciones,this.artista.pathImagen,
        this.artista.idAlbumes,this.artista.idGeneros);
      this.servicio.modificarArtista(artistaCambiar);
    }
  }

  //Getter del campo nombreArtista del formulario
  get campoArtista(){ return this.editarArtistaForm.get('nombreArtista'); }

  //Validacion del campo nombreArtista del formulario
  get campoArtistaValido() { return this.campoArtista.valid && this.campoArtista.touched; }
  get campoArtistaInvalido() { return this.campoArtista.invalid && this.campoArtista.touched; }

}
