import { Component,EventEmitter,Input, Output } from '@angular/core';
import { ListaReproduccion } from '../../../models/lista-reproduccion';
import { CommonModule } from '@angular/common';
import { Artista } from '../../../models/artista';
import { Cancion } from '../../../models/cancion';


@Component({
  selector: 'app-lista-reproduccion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lista-reproduccion.component.html',
  styleUrl: './lista-reproduccion.component.css'
})
export class ListaReproduccionComponent {
  //Recibo del componente madre toda la informacion necesaria para nutrir este componente
  @Input() lista:ListaReproduccion;
  @Input() cancionesLista:Cancion[]=[];
  @Input() artistasLista:Artista[]=[];

  @Output() eliminarCancion= new EventEmitter<[number,number]>;//Emito el id de cancion a eliminar y el id de la lista de donde se debe de eliminar
  @Output() artistaSeleccionado = new EventEmitter<number>//Emito el id del Artista del que quiero mostrar la vista

  //Funcion que devuelve un objeto artista en funcion de su id, uso esta funcion para listar las canciones con su artista.
  devolverArtista(id:number){
    return this.artistasLista.find(artista => artista.id == id);
  }

  //Funcion que emite el id de artista para mostrar su vista
  artistaSeleccion(id:number){
    this.artistaSeleccionado.emit(id);
  }

  //Funcion que emite el id de cancion/lista para eliminar dicha cancion de la lista con id coincidente.
  eliminarCancionLista(cancionId:number){
    this.eliminarCancion.emit([cancionId,this.lista.id]);
  }
}
