import { Component } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { HeaderComponent } from "../header/header.component";

@Component({
  selector: 'app-mapa-web',
  standalone: true,
  imports: [FooterComponent, HeaderComponent],
  templateUrl: './mapa-web.component.html',
  styleUrl: './mapa-web.component.css'
})
export class MapaWebComponent {

}
