import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Artista } from '../../../models/artista';
import { FormArray, FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Genero } from '../../../models/genero';
import { GestorDatosService } from '../../gestor-datos.service';
import { Album } from '../../../models/album';

@Component({
  selector: 'app-formulario-nuevo-album',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './formulario-nuevo-album.component.html',
  styleUrl: './formulario-nuevo-album.component.css'
})
export class FormularioNuevoAlbumComponent {
  @Input() artista:Artista;
  @Input() generos:Genero[]=[];
  formAlbum:FormGroup;
  @Output() cerrarForm=new EventEmitter<boolean>;

  constructor(private fb:FormBuilder , private servicio:GestorDatosService){
    this.formAlbum = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: [''],
      imagen: [null], 
      fecha: ['', Validators.required],
      generos: this.fb.array([]) // FormArray para los checkboxes de géneros
    });
  }

  get generosArray(): FormArray {
    return this.formAlbum.get('generos') as FormArray;
  }

  //Funcion que agrega o quita elementos del Formarray de los checkbox
  onCheckboxChange(event: any, generoId: number) {
    if (event.target.checked) {//Comprobamos si el checkbox se selecciono
      this.generosArray.push(new FormControl(generoId));//Agregamos el id al array de generos seleccionados
    } else {//Se se desmarcó el checkbox
      let indice = this.generosArray.controls.findIndex(indiceGenero => indiceGenero.value == generoId); //Buscamos el indice del que fue desmarcado
      if (indice != -1){//Si se encontro el indice
        this.generosArray.removeAt(indice);//Eliminamos del array dicho indice
      } 
    }
  }

  cerrarFormulario(){
    this.cerrarForm.emit(true);
  }

  crearAlbum(){
    if(this.formAlbum.valid && this.checkGeneros()){
      let nuevoAlbum=new Album(this.servicio.albumes.at(-1).id+1,this.campoNombre.value,this.campoDescripcion.value,
      this.campoFecha.value,[],"media/img/usuario-generica.jpg",this.campoGeneros.value);
      this.servicio.anadirAlbum(nuevoAlbum);
      this.cerrarFormulario();
    }else {
      this.formAlbum.markAllAsTouched();
    }
  }

  //Getters del formulario
  get campoNombre(){ return this.formAlbum.get('nombre') }
  get campoDescripcion(){ return this.formAlbum.get('descripcion') }
  get campoFecha(){ return this.formAlbum.get('fecha') }
  get campoGeneros(){ return this.formAlbum.get('generos') }

  //Validaciones del formulario
  get nombreValido(){ return this.campoNombre.valid && this.campoNombre.touched }
  get nombreInvalido(){ return this.campoNombre.invalid && this.campoNombre.touched }

  get descripcionValido(){ return this.campoDescripcion.valid && this.campoDescripcion.touched }
  get descripcionInvalido(){ return this.campoDescripcion.invalid && this.campoDescripcion.touched }

  get fechaValido(){ return this.campoFecha.valid && this.campoFecha.touched }
  get fechaInvalido(){ return this.campoFecha.invalid && this.campoFecha.touched }

  get generoValido(){ return this.campoGeneros.valid && this.campoGeneros.touched }
  get generoInvalido(){ return this.campoGeneros.invalid && this.campoGeneros.touched }
  
  checkGeneros() {
    if(this.campoGeneros.value.length > 0){
      return true;
    }else {
      return false;
    }
  }

}
