import { Component } from '@angular/core';

@Component({
  selector: 'app-vista-album',
  standalone: true,
  imports: [],
  templateUrl: './vista-album.component.html',
  styleUrl: './vista-album.component.css'
})
export class VistaAlbumComponent {

}
