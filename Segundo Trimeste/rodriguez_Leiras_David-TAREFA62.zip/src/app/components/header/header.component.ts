import { Component,EventEmitter,Input, OnInit, Output } from '@angular/core';
import { Usuario } from '../../../models/usuario';
import { CommonModule } from '@angular/common';
import { ServicioLoginService } from '../../servicio-login.service';
import { Router, RouterLink } from '@angular/router';
import { GestorDatosService } from '../../gestor-datos.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule,RouterLink],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  mostrarMenu:boolean=false;//booleano que usamos para mostrar o ocultar el desplegable del menu de usuario
  @Input() home:boolean=true;//Recibimos si se ha pulsado el boton de home
  usuarioSesion:Usuario;//usuario con sesion iniciada actualmente
  @Output() seleccionarHome = new EventEmitter<boolean>;//Output que indica si el boton de Home se ha pulsado

  constructor(private servicio:GestorDatosService,private servicioLogin:ServicioLoginService, private router:Router){ }

  //Funcion que muestra o oculta el menu de usuario en base al booleano "mostrarMenu"
  subMenu(){
    if(!this.mostrarMenu){
      this.mostrarMenu=true;
    }else{
      this.mostrarMenu=false;
    }
  }

  //Funcion para seleccionar el home, esto es en funcion del valor de "home" , tambien emite hacia el componente madre el valor de seleccionarHome
  //de esta manera, si hay otros componentes visibles los oculta y muestra este componente.
  selectHome(){
    this.home=true;
    this.seleccionarHome.emit(true);
  }
  //Comprobamos si estamos en el inicio y devolvemos true si lo estamos y false si no, esta funcion la uso para mostrar o no en el header la barra de buscar
  //no tendria sentido por ejemplo poder buscar desde el perfil de usuario por razones de diseño de la pagina.
  checkRuta(){
    if(this.router.isActive('/inicio',true)){
      return true;
    }else {
      return false;
    }
  }

  //Funcion de cerrar sesion, la cual llama a la funcion de cerrarSesion() del servicio y redirije a la portada.
  cerrarSesion(){
    this.servicioLogin.cerrarSesion();
    this.router.navigate(['/portada']);
  }

  ngOnInit(): void {
    //Hacemos la subscripcion del usuario logado en servicioLogin
    this.servicio.subscribirse$('usuario').subscribe((user)=>{ this.usuarioSesion = user; })
  }
}
