import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { ServicioLoginService } from '../../servicio-login.service';
import { Usuario } from '../../../models/usuario';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormBuilder, FormGroup,Validators } from '@angular/forms';
import { GestorDatosService } from '../../gestor-datos.service';
import { Artista } from '../../../models/artista';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-administrar',
  standalone: true,
  imports: [HeaderComponent, FooterComponent,CommonModule,ReactiveFormsModule,RouterLink],
  templateUrl: './administrar.component.html',
  styleUrl: './administrar.component.css'
})
export class AdministrarComponent implements OnInit{
  usuarios:Usuario[]=[];
  usuarioMod:Usuario;
  artistas:Artista[]=[];
  formularioCrear:FormGroup;//Defino el formulario de creacion de Usuario
  formularioModificar:FormGroup;
  formCrear:boolean=false;
  formModificar:boolean=false;

  constructor(private servicioLogin:ServicioLoginService,private servicioDatos:GestorDatosService, private form:FormBuilder){
    this.formularioCrear = this.form.group({
      usuario:['',[Validators.required]],
      nombre:['',[Validators.required]],
      apellidos:['',[Validators.required]],
      email:['',[Validators.required,Validators.email]],
      planVibe:[false,[Validators.required]],
      rol:['-1',[]]
    });
  }

  ngOnInit(): void {
    this.servicioLogin.subscribirUsuarios().subscribe((usuarios)=>{this.usuarios=usuarios;});
    this.servicioDatos.subscribirse$('artistas').subscribe((artistas)=>{this.artistas=artistas});
  }

  //Muestra o oculta  y resetea el formulario de Creacion de Usuario en base al valor del booleano formCrear,
  //Tambien oculta el formulario de modificacion si este estuviera abierto.
  mostrarCrear(){
    if(this.formCrear){
      this.formCrear=false;
      this.formularioCrear.reset();
    }else {
      this.formModificar=false;
      this.formCrear=true;
    }
  }
  //Muestra o oculta  y resetea el formulario de Modificacion de Usuario en base al valor del booleano formModificar,
  //Tambien oculta el formulario de modificacion si este estuviera abierto.
  mostrarModificar(id:number){
    if(this.formModificar){
      this.formModificar=false;
      this.formularioModificar.reset();
      this.usuarioMod=null;
    }else {
      this.formCrear=false;
      this.formModificar=true;
      this.usuarioMod= this.usuarios.find((usuario) => usuario.id == id);
      this.formularioModificar = this.form.group({
        usuario:[this.usuarioMod.nombreUsuario,[Validators.required]],
        nombre:[this.usuarioMod.nombre,[Validators.required]],
        apellidos:[this.usuarioMod.apellidos,[Validators.required]],
        email:[this.usuarioMod.email,[Validators.required,Validators.email]],
        planVibe:[this.usuarioMod.planVibe,[Validators.required]],
        rol:[this.usuarioMod.rol,[]]
      });
    }
  }
  //Uso este metodo para comparar el usuario iterando en la lista de usuarios y no permitir el borrado
  //si el usuario que itera es el mismo que tiene iniciada la sesion.
  comprobarUsuarioSesion(id:number){
    let idActual= JSON.parse(sessionStorage.getItem("usuario"))._id;
    if(id != idActual){
      return true;
    }else {
      return false;
    }
  }

  //Funcion para registrar un nuevo usuario, esta crea un nuevo objeto usuario con los campos del  formulario rellenando con informacion generica las propiedades
  //no incluidas en el mismo.
  registrar(evento: Event){
    evento.preventDefault();
    if(this.formularioCrear.valid && this.rolCrearValido){ //Si el formulario pasa la validacion entonces se crea.
      let lastId=this.usuarios.at(-1).id;
      let usuario:Usuario= new Usuario(lastId+1,this.formularioCrear.value['usuario'],this.formularioCrear.value['nombre'],
      this.formularioCrear.value['apellidos'],this.formularioCrear.value['email'],'abc123..',this.formularioCrear.value['rol'],
      this.formularioCrear.value['planVibe'],1,[]);
      this.servicioLogin.registrarUsuario(usuario); //Llamada a la funcion de registro de usuario en el servicio de Login.
      this.mostrarCrear(); // Llamada a la funcion para ocultar el formulario
    }else {
      this.formularioCrear.markAllAsTouched();
    }
  }
  //Funcion de borrado de usuario, hace una llamada al servicio login pasandole como parametro el id del usuario a borrar
  borrar(id:number){
    this.servicioLogin.borrarUsuario(id);
  }

  //Esta funcion hace lo mismo que la funcion de registrar, solo que el nuevo objeto usuario se crea en base 
  modificar(evento: Event){
    evento.preventDefault();
    if(this.formularioModificar.valid){ //Si el formulario pasa la validacion entonces se crea.
    let usuario:Usuario= new Usuario(this.usuarioMod.id,this.formularioModificar.value['usuario'],this.formularioModificar.value['nombre'],
      this.formularioModificar.value['apellidos'],this.formularioModificar.value['email'],this.usuarioMod.contrasena,this.formularioModificar.value['rol'],
      this.formularioModificar.value['planVibe'],this.usuarioMod.idArtista,this.usuarioMod.idListasReproduccion);
      this.servicioLogin.modificarUsuario(usuario);
      this.mostrarModificar(0);
    }else {
      console.log('invalido');
      this.formularioModificar.markAllAsTouched();
    }
  }

  comprobarArtista(idArtista:number){
    let artista= this.artistas.find(artista=>artista.id == idArtista);
    return artista;
  }

  //Getters del formularioCrear
  get campoUsuarioCrear() { return this.formularioCrear.get('usuario') }
  get campoNombreCrear() { return this.formularioCrear.get('nombre') }
  get campoApellidosCrear() { return this.formularioCrear.get('apellidos') }
  get campoEmailCrear() { return this.formularioCrear.get('email') }
  get campoPlanCrear() { return this.formularioCrear.get('planVibe') }
  get campoRolCrear() { return this.formularioCrear.get('rol') }

  //Getters del formularioModificar
  get campoUsuarioModificar() { return this.formularioModificar.get('usuario') }
  get campoNombreModificar() { return this.formularioModificar.get('nombre') }
  get campoApellidosModificar() { return this.formularioModificar.get('apellidos') }
  get campoEmailModificar() { return this.formularioModificar.get('email') }
  get campoPlanModificar() { return this.formularioModificar.get('planVibe') }
  get campoRolModificar() { return this.formularioModificar.get('rol') }

  //Validaciones de formularioCrear
  get usuarioCrearValido() { return this.campoUsuarioCrear.valid && this.campoUsuarioCrear.touched; }
  get usuarioCrearInvalido() { return this.campoUsuarioCrear.invalid && this.campoUsuarioCrear.touched; }

  get nombreCrearValido() { return this.campoNombreCrear.valid && this.campoNombreCrear.touched; }
  get nombreCrearInvalido() { return this.campoNombreCrear.invalid && this.campoNombreCrear.touched; }

  get apellidoCrearValido() { return this.campoApellidosCrear.valid && this.campoApellidosCrear.touched; }
  get apellidoCrearInvalido() { return this.campoApellidosCrear.invalid && this.campoApellidosCrear.touched; }

  get emailCrearValido() { return this.campoEmailCrear.valid && this.campoEmailCrear.touched; }
  get emailCrearInvalido() { return this.campoEmailCrear.invalid && this.campoEmailCrear.touched; }

  get planCrearValido() { return this.campoPlanCrear.valid && this.campoPlanCrear.touched; }
  get planCrearInvalido() { return this.campoPlanCrear.invalid && this.campoPlanCrear.touched; }

  get rolCrearValido() { return (this.campoRolCrear.value != -1) && this.campoRolCrear.touched; }
  get rolCrearInvalido() { return (this.campoRolCrear.value == -1)&& this.campoRolCrear.touched; }

  //Validaciones de formularioModificar
  get usuarioModificarValido() { return this.campoUsuarioModificar.valid && this.campoUsuarioModificar.touched; }
  get usuarioModificarInvalido() { return this.campoUsuarioModificar.invalid && this.campoUsuarioModificar.touched; }

  get nombreModificarValido() { return this.campoNombreModificar.valid && this.campoNombreModificar.touched; }
  get nombreModificarInvalido() { return this.campoNombreModificar.invalid && this.campoNombreModificar.touched; }

  get apellidoModificarValido() { return this.campoApellidosModificar.valid && this.campoApellidosModificar.touched; }
  get apellidoModificarInvalido() { return this.campoApellidosModificar.invalid && this.campoApellidosModificar.touched; }

  get emailModificarValido() { return this.campoEmailModificar.valid && this.campoEmailModificar.touched; }
  get emailModificarInvalido() { return this.campoEmailModificar.invalid && this.campoEmailModificar.touched; }

  get planModificarValido() { return this.campoPlanModificar.valid && this.campoPlanModificar.touched; }
  get planModificarInvalido() { return this.campoPlanModificar.invalid && this.campoPlanModificar.touched; }

  get rolModificarValido() { return (this.campoRolModificar.value != -1) && this.campoRolModificar.touched; }
  get rolModificarInvalido() { return (this.campoRolModificar.value == -1)&& this.campoRolModificar.touched; }

}
