import { Component, ElementRef, inject, OnInit, PLATFORM_ID, ViewChild } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { Router, RouterLink } from '@angular/router';
import { HeaderComponent } from "../header/header.component";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Usuario } from '../../../models/usuario';
import { ServicioLoginService } from '../../servicio-login.service';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [FooterComponent, ReactiveFormsModule, HeaderComponent, CommonModule],
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.css'
})
export class RegistroComponent implements OnInit{
  formularioCrear: FormGroup; // Defino el formulario de creacion de usuario
  formPremium:boolean=false;
  navegador: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  constructor(private form: FormBuilder, private servicioLogin:ServicioLoginService,private router:Router) {
    this.formularioCrear = this.form.group({
      usuario: ['', [Validators.required]],
      nombre: ['', [Validators.required]],
      apellidos: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      contrasena: ['',[Validators.required]],
      repiteContrasena: ['',[Validators.required]],
      planVibe: [false, [Validators.required]],
      //Este formulario se agregara dinamicamente cuando se selecciones el Plan Premium
      planPremiumForm: this.form.group({
        nombreTarjeta:['',[]],
        numeroTarjeta:['',[]],
        fechaCaducidadMes:['',[]],
        fechaCaducidadAno:['',[]],
        csv:['',[]],
      }),
      terminos: ['',[Validators.required]],
      politicas: ['',[Validators.required]]
    });
  }

  ngOnInit(): void {
    //Si el hay una sesion, redirigimos a /inicio
    if (this.navegador) {
      if(sessionStorage.getItem("usuario")){
        this.router.navigate(['/inicio']);
      }
    }
    //Hacemos suscripcion a los cambios sobre el Plan seleccionado
    this.campoPlanCrear.valueChanges.subscribe(valor => {
      //Recojo la referencia del formulario de pago
      let formularioPago = this.formularioCrear.get('planPremiumForm') as FormGroup;
      //Cuando se seleccione el Plan premium (valor true)
      if(valor){
        //Habilitamos el formulario de pago
        formularioPago.enable();
        //Establecemos las validaciones
        formularioPago.get('nombreTarjeta').setValidators([Validators.required]);
        formularioPago.get('numeroTarjeta').setValidators([Validators.required,Validators.pattern(/^\d{16}$/)]);
        formularioPago.get('fechaCaducidadMes').setValidators([Validators.required,Validators.pattern(/^\d{2}$/)]);
        formularioPago.get('fechaCaducidadAno').setValidators([Validators.required,Validators.pattern(/^\d{2}$/)]);
        formularioPago.get('csv').setValidators([Validators.required,Validators.pattern(/^\d{3}$/)]);
      } else {//Cuando se seleccione el Plan Standard (valor false)
        formularioPago.reset();
        formularioPago.disable();//Deshabilito el formmulario de pago
        //Limpiamos las validaciones
        formularioPago.get('nombreTarjeta').clearValidators();
        formularioPago.get('numeroTarjeta').clearValidators();
        formularioPago.get('fechaCaducidadMes').clearValidators();
        formularioPago.get('fechaCaducidadAno').clearValidators();
        formularioPago.get('csv').clearValidators();
      }
      //Actualizamos los campos de tal manera que si el formulario esta activo, se establecen sus validaciones y si no estas estaran vacias
      formularioPago.get('nombreTarjeta').updateValueAndValidity();
      formularioPago.get('numeroTarjeta').updateValueAndValidity();
      formularioPago.get('fechaCaducidadMes').updateValueAndValidity();
      formularioPago.get('fechaCaducidadAno').updateValueAndValidity();
      formularioPago.get('csv').updateValueAndValidity();
    })
  }

  //Funcion para registrar un nuevo usuario, esta crea un nuevo objeto usuario con los campos del  formulario rellenando con informacion generica las propiedades
    //no incluidas en el mismo.
    registrar(evento: Event){
      evento.preventDefault();
      if(this.formularioCrear.valid && this.comprobarContrasena()){ //Si el formulario pasa la validacion entonces se crea.
        let lastId=this.servicioLogin.usuarios.at(-1).id;
        let usuario:Usuario= new Usuario(lastId+1,this.campoUsuarioCrear.value,this.campoNombreCrear.value,
        this.campoApellidosCrear.value,this.campoEmailCrear.value,this.campoContrasena.value,'usuario',this.campoPlanCrear.value
        ,lastId,[]);
        this.servicioLogin.registrarUsuario(usuario); //Llamada a la funcion de registro de usuario en el servicio de Login.
        if(this.servicioLogin.iniciarSesion(usuario.nombreUsuario,usuario.contrasena)){
          this.router.navigate(['/inicio']);
        }
      }else {
        console.log('No se valido');
        this.formularioCrear.markAllAsTouched();
      }
    }
  
  mostrarFormPremium(){ this.formPremium=true; }
  ocultarFormPremium(){ this.formPremium=false; }

  //Getters del formularioCrear
  get campoUsuarioCrear() { return this.formularioCrear.get('usuario') }
  get campoNombreCrear() { return this.formularioCrear.get('nombre') }
  get campoApellidosCrear() { return this.formularioCrear.get('apellidos') }
  get campoEmailCrear() { return this.formularioCrear.get('email') }
  get campoContrasena() { return this.formularioCrear.get('contrasena') }
  get campoRepiteContrasena() { return this.formularioCrear.get('repiteContrasena') }
  get campoPlanCrear() { return this.formularioCrear.get('planVibe') }
  get campoNombreTarjetaCrear() { return this.formularioCrear.get('planPremiumForm').get('nombreTarjeta') }
  get campoNumTarjetaCrear() { return this.formularioCrear.get('planPremiumForm').get('numeroTarjeta') }
  get campoFechaMesCrear() { return this.formularioCrear.get('planPremiumForm').get('fechaCaducidadMes') }
  get campoFechaAnoCrear() { return this.formularioCrear.get('planPremiumForm').get('fechaCaducidadAno') }
  get campoCsvCrear() { return this.formularioCrear.get('planPremiumForm').get('csv') }
  get campoTerminosCrear() { return this.formularioCrear.get('terminos') }
  get campoPoliticasCrear() { return this.formularioCrear.get('politicas') }
  

  //Validaciones de formularioCrear
  get usuarioCrearValido() { return this.campoUsuarioCrear.valid && this.campoUsuarioCrear.touched; }
  get usuarioCrearInvalido() { return this.campoUsuarioCrear.invalid && this.campoUsuarioCrear.touched; }

  get nombreCrearValido() { return this.campoNombreCrear.valid && this.campoNombreCrear.touched; }
  get nombreCrearInvalido() { return this.campoNombreCrear.invalid && this.campoNombreCrear.touched; }

  get apellidoCrearValido() { return this.campoApellidosCrear.valid && this.campoApellidosCrear.touched; }
  get apellidoCrearInvalido() { return this.campoApellidosCrear.invalid && this.campoApellidosCrear.touched; }

  get emailCrearValido() { return this.campoEmailCrear.valid && this.campoEmailCrear.touched; }
  get emailCrearInvalido() { return this.campoEmailCrear.invalid && this.campoEmailCrear.touched; }

  get contrasenaCrearValido() { return this.campoContrasena.valid && this.campoContrasena.touched; }
  get contrasenaCrearInvalido() { return this.campoContrasena.invalid && this.campoContrasena.touched; }

  get repiteContrasenaCrearValido() { return this.campoRepiteContrasena.valid && this.campoRepiteContrasena.touched; }
  get repiteContrasenaCrearInvalido() { return this.campoRepiteContrasena.invalid && this.campoRepiteContrasena.touched; }
  //Valido si las contraseñas coinciden
  get repiteContrasenaCheck() { return this.contrasenaCrearValido && this.campoRepiteContrasena.touched && !this.comprobarContrasena() }

  get planCrearValido() { return this.campoPlanCrear.valid && this.campoPlanCrear.touched; }
  get planCrearInvalido() { return this.campoPlanCrear.invalid && this.campoPlanCrear.touched; }

  get nombreTarjetaCrearValido() { return this.campoNombreTarjetaCrear.valid && this.campoNombreTarjetaCrear.touched; }
  get nombreTarjetaCrearInvalido() { return this.campoNombreTarjetaCrear.invalid && this.campoNombreTarjetaCrear.touched; }
  
  get numeroTarjetaCrearValido(){ return this.campoNumTarjetaCrear.valid && this.campoNumTarjetaCrear.touched; }
  get numeroTarjetaCrearInvalido(){ return this.campoNumTarjetaCrear.invalid && this.campoNumTarjetaCrear.touched; }

  get fechaCaducidadAnoCrearValido() { return this.campoFechaAnoCrear.valid && this.campoFechaAnoCrear.touched; }
  get fechaCaducidadAnoCrearInvalido() {return this.campoFechaAnoCrear.invalid && this.campoFechaAnoCrear.touched;}

  get fechaCaducidadMesCrearValido() { return this.campoFechaMesCrear.valid && this.campoFechaMesCrear.touched; }
  get fechaCaducidadMesCrearInvalido() {return this.campoFechaMesCrear.invalid && this.campoFechaMesCrear.touched;}

  get csvCrearValido() { return this.campoCsvCrear.valid && this.campoCsvCrear.touched; }
  get csvCrearInvalido() { return this.campoCsvCrear.invalid && this.campoCsvCrear.touched; }

  get politicasCrearValido() { return this.campoPoliticasCrear.valid && this.campoPoliticasCrear.touched; }
  get politicasCrearInvalido() { return this.campoPoliticasCrear.invalid && this.campoPoliticasCrear.touched; }

  get terminosCrearValido() { return this.campoTerminosCrear.valid && this.campoTerminosCrear.touched; }
  get terminosCrearInvalido() { return this.campoTerminosCrear.invalid && this.campoTerminosCrear.touched; }


  //Funcion que comprueba si las contraseñas del formulario coinciden
  comprobarContrasena(){
    return this.campoContrasena.value === this.campoRepiteContrasena.value ? true : false;
  }
}
