import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { HeaderComponent } from "../header/header.component";
import { Usuario } from '../../../models/usuario';
import { GestorDatosService } from '../../gestor-datos.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ServicioLoginService } from '../../servicio-login.service';
import { Artista } from '../../../models/artista';
import { Genero } from '../../../models/genero';

@Component({
  selector: 'app-perfil',
  standalone: true,
  imports: [FooterComponent, HeaderComponent, CommonModule, ReactiveFormsModule],
  templateUrl: './perfil.component.html',
  styleUrl: './perfil.component.css'
})
export class PerfilComponent implements OnInit {
  usuario: Usuario;
  artista: Artista;
  generos: Genero[];
  formPremium: boolean = false;
  contrasenaCambiada:boolean=false;
  planPremiumForm: FormGroup;
  cambiarContrasenaForm:FormGroup;

  constructor(private servicio: GestorDatosService,private servicioLogin:ServicioLoginService, private fb: FormBuilder) {
    this.planPremiumForm = this.fb.group({
      nombreTarjeta: ['', [Validators.required]],
      numeroTarjeta: ['', [Validators.required, Validators.pattern(/^\d{16}$/)]],
      fechaCaducidadMes: ['', [Validators.required, Validators.pattern(/^\d{2}$/)]],
      fechaCaducidadAno: ['', [Validators.required, Validators.pattern(/^\d{2}$/)]],
      csv: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]],
    });
    this.cambiarContrasenaForm = this.fb.group({
      contrasena:['', [Validators.required]],
      repiteContrasena:['', [Validators.required]]
    })
  }

  ngOnInit(): void {
    this.servicio.subscribirse$('usuario')!.subscribe((usuario: Usuario) => { this.usuario = usuario });
    this.servicio.subscribirse$('artista')!.subscribe((artista:Artista)=> { this.artista= artista });
    this.servicio.subscribirse$('generos')!.subscribe((genero:Genero[])=>{this.generos=genero} );
  }

  //Funcion que oculta y muestra el formulario de pago utilizando el boolean formPremium
  mostrarFormulario(){
    this.formPremium=!this.formPremium;
    if(this.formPremium){
      this.planPremiumForm.reset();
    }
  }

  //Funcion que cambia el plan del usuario si pasa la validacion del formularieo
  cambiarPlan(){
    if(this.planPremiumForm.valid){
      let user=new Usuario(this.usuario.id,this.usuario._nombreUsuario,this.usuario.nombre,this.usuario.apellidos,
        this.usuario.email,this.usuario.contrasena,this.usuario.rol,true,this.usuario.idArtista,
        this.usuario.idListasReproduccion);
      this.servicioLogin.modificarUsuario(user);
      this.cambiarContrasenaForm.reset();
    }else {
      this.planPremiumForm.markAllAsTouched();
    }
  }

  //Funcion que cambia la contraseña del usuario con sesion iniciada si pasa la validacion del formulario
  cambiarContrasena(){
    if(this.cambiarContrasenaForm.valid){
      let user=new Usuario(this.usuario.id,this.usuario._nombreUsuario,this.usuario.nombre,this.usuario.apellidos,
        this.usuario.email,this.campoContrasena.value,this.usuario.rol,this.usuario.planVibe,this.usuario.idArtista,
        this.usuario.idListasReproduccion);
      this.servicioLogin.modificarUsuario(user);
      this.cambiarContrasenaForm.reset();
      this.contrasenaCambiada=true;
    }else {
      this.contrasenaCambiada=false;
      this.cambiarContrasenaForm.markAllAsTouched();
    }
  }

  //Funcion que comprueba si las contraseñas del formulario coinciden
  comprobarContrasena(){
    return this.campoContrasena.value === this.campoRepiteContrasena.value ? true : false;
  }

  //Getters del formulario contraseña
  get campoContrasena() { return this.cambiarContrasenaForm.get('contrasena') }
  get campoRepiteContrasena() { return this.cambiarContrasenaForm.get('repiteContrasena') }

  //Getters del formulario de tarjeta
  get campoNombreTarjeta() { return this.planPremiumForm.get('nombreTarjeta') }
  get campoNumTarjeta() { return this.planPremiumForm.get('numeroTarjeta') }
  get campoFechaMes() { return this.planPremiumForm.get('fechaCaducidadMes') }
  get campoFechaAno() { return this.planPremiumForm.get('fechaCaducidadAno') }
  get campoCsv() { return this.planPremiumForm.get('csv') }

  //Validaciones del formulario contraseña
  get contrasenaCrearValido() { return this.campoContrasena.valid && this.campoContrasena.touched; }
  get contrasenaCrearInvalido() { return this.campoContrasena.invalid && this.campoContrasena.touched; }

  get repiteContrasenaCrearValido() { return this.campoRepiteContrasena.valid && this.campoRepiteContrasena.touched; }
  get repiteContrasenaCrearInvalido() { return this.campoRepiteContrasena.invalid && this.campoRepiteContrasena.touched; }
  //Valido si las contraseñas coinciden
  get repiteContrasenaCheck() { return this.contrasenaCrearValido && this.campoRepiteContrasena.touched && !this.comprobarContrasena() }

  //Validaciones del formulario de tarjeta
  get nombreTarjetaValido() { return this.campoNombreTarjeta.valid && this.campoNombreTarjeta.touched; }
  get nombreTarjetaInvalido() { return this.campoNombreTarjeta.invalid && this.campoNombreTarjeta.touched; }
  
  get numeroTarjetaValido(){ return this.campoNumTarjeta.valid && this.campoNumTarjeta.touched; }
  get numeroTarjetaInvalido(){ return this.campoNumTarjeta.invalid && this.campoNumTarjeta.touched; }

  get fechaCaducidadAnoValido() { return this.campoFechaAno.valid && this.campoFechaAno.touched; }
  get fechaCaducidadAnoInvalido() {return this.campoFechaAno.invalid && this.campoFechaAno.touched;}

  get fechaCaducidadMesValido() { return this.campoFechaMes.valid && this.campoFechaMes.touched; }
  get fechaCaducidadMesInvalido() {return this.campoFechaMes.invalid && this.campoFechaMes.touched;}

  get csvValido() { return this.campoCsv.valid && this.campoCsv.touched; }
  get csvInvalido() { return this.campoCsv.invalid && this.campoCsv.touched; }


}
