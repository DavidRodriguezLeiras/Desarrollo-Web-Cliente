import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, ElementRef, Input, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Cancion } from '../../../models/cancion';
import { Artista } from '../../../models/artista';

@Component({
  selector: 'app-reproductor',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './reproductor.component.html',
  styleUrl: './reproductor.component.css'
})
export class ReproductorComponent implements OnChanges,AfterViewInit {
  @Input() canciones:Cancion[];//Canciones recibidas que conforman la lista de reproduccion actual
  @Input() indiceInicial:number;//Indice inicial que recibimos desde donde se empezara a reproducir la lista
  @Input() artistas:Artista[];//Informacion de los artistas necesaria para rellenar informacion, como el titulo o la imagen de la cancion a reproducir
  @ViewChild('reproductor')reproductorReferencia:ElementRef<HTMLAudioElement>; //Referencia al reproductor de audio
  progreso:number=0;//Valor utilizado en la barra de progreso de la cancion
  volumen:number=40;//Valor utilizado de base en el selector de volumen
  pausarReproducir:boolean=false;//Booleano que uso para ocultar/mostrar el boton de Play/pause
  indiceActual:number;//Indice para saber en que posicion de la lista de reproduccion estoy
  reproductorActivo:boolean=false;//Boleano que me sirve para indicar si el reproductor esta activo o no
  silenciado:boolean=false;//Booleano que uso cuando quiero silenciar el reproductor y mostrar un icono u otro
  tiempoActual:string;//String que contiene el tiempo actual de la cancion mientras se reproduce
  tiempoTotal:string//String que contiene el tiempo total de la cancion en reproduccion

  //Comprobamos los cambios sobre el input indiceInicial para dar el valor de indice desde el que reproducimos
  ngOnChanges(changes: SimpleChanges): void {
      if(changes['indiceInicial']){
        this.indiceActual=this.indiceInicial;
        this.cargarCancion();//Hacemos la primera carga de cancion en el reproductor
      }
  }
  //Cuando este todo cargado
  ngAfterViewInit(): void {
    let reproductor=this.reproductorReferencia.nativeElement;//Recogemos la referencia del reproductor
    
    //A traves del evento timeupdate vamos recalculando el tiempo a mostrar en el tiempo Actual
    reproductor.addEventListener('timeupdate',()=>{
      this.tiempoActual=this.calcularTiempo(reproductor.currentTime);
    })
    //A traves del evento loadedmetadata calculamos el tiempo total de la cancion
    reproductor.addEventListener('loadedmetadata',()=>{
      this.tiempoTotal=this.calcularTiempo(reproductor.duration);
    })
    //Cuando termina la cancion a traves del evento ended ejecutamos la siguiente cancion.
    reproductor.addEventListener('ended',()=> this.cancionSiguiente());
  }

  //Colocamos el punto de reproduccion de la cancion en funcion del valor de progreso
  posicionBarra(){
    let reproductor=this.reproductorReferencia.nativeElement;
    reproductor.currentTime=(this.progreso /100)*reproductor.duration;
  }

  //Pausamos o reanudamos la reproduccion den la cancion , tambien cambiamos el valor de pausarReproducir para cambiar los iconos del reproductor
  playPausa(){
    let reproductor=this.reproductorReferencia.nativeElement;
    if(reproductor.paused){
      reproductor.play();
      this.pausarReproducir=true;
    }else {
      reproductor.pause();
      this.pausarReproducir=false;
    }
  }

  //Vamos a la cancion anterior, si estamos en el principio de la lista, 
  cancionPrevia(){ 
    if(this.indiceActual>0){
      this.indiceActual=this.indiceActual - 1
      this.cargarCancion();
    }else {
      this.playPausa();
      this.progreso=0;
      this.posicionBarra();
    }
  }

  //Pasamos a la cancion en la posicion siguiente, si no hay mas hacia adelante, detenemos el reproductor.
  cancionSiguiente(){
    if(this.canciones.length < this.indiceActual+1){
      this.playPausa();
      this.progreso=0;
      this.posicionBarra();
    }else {
      this.indiceActual = this.indiceActual + 1;
      this.cargarCancion();
    }
  }

  //Cambiamos el valor del volumen en funcion del valor de la variable volumen/100 ya que el valor de volumen del reproductor va
  //desde 0.0 a 1
  cambiarVolumen(){ 
    this.reproductorReferencia.nativeElement.volume=this.volumen/100;
  }

  //Funcion que realiza la carga en el reproductor de la cancion a reproducir
  cargarCancion(){
    //Como esta funcion la llamo desde el ngOnChanges, hago el check de si esta inicializado el reproductor de esta manera, si el reproductor no esta activo
    //no causa problemas en la carga del resto de componentes.
    if(!this.reproductorReferencia || !this.reproductorReferencia.nativeElement){
      return;
    }
    let reproductor=this.reproductorReferencia.nativeElement;
    reproductor.src=this.canciones[this.indiceActual].pathCancion;
    reproductor.play();
    this.pausarReproducir=true;
    this.reproductorActivo=true;
  }

  //Funcion que devuelve el artista en funcion de el id de Cancion
  devolverArtista(idCancion:number){
    return this.artistas.find(artista=> artista.idCanciones.includes(idCancion));
  }

  calcularTiempo(segundos:number){
    let minutos = Math.floor(segundos / 60);
    let segundosRestantes = Math.floor(segundos % 60);
    return ""+minutos+":"+segundosRestantes;
  }

  //Funcion que sirve para silenciar o activar el sonido
  silenciar(){
    if(this.silenciado){
      this.volumen=20;
      this.cambiarVolumen();
      this.silenciado=false;
    }else{
      this.volumen=0;
      this.cambiarVolumen();
      this.silenciado=true;
    }
    
  }
}
