import { Component } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { HeaderComponent } from "../header/header.component";
import { FormGroup,FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contacto',
  standalone: true,
  imports: [FooterComponent, HeaderComponent,ReactiveFormsModule,CommonModule],
  templateUrl: './contacto.component.html',
  styleUrl: './contacto.component.css'
})
export class ContactoComponent {
  formularioContacto:FormGroup;//Declaramos el formulario
  mensajeEnviado:boolean;

  constructor(private fb:FormBuilder){
    //Inicializamos el formulario
    this.formularioContacto = fb.group({
      nombre: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      asunto: ['', [Validators.required]],
      descripcion: ['', [Validators.required]]
    })

  }

  //Funcion que enviará el mensaje desde el formulario
  enviarMensaje(){
    if(this.formularioContacto.valid){
      this.mensajeEnviado=true;
      console.log('Se envio el formulario');
      this.formularioContacto.reset();
    }else {
      this.mensajeEnviado=false;
      this.formularioContacto.markAllAsTouched();
    }
  }
  //Getters del formulario de contacto
  get campoNombre() { return this.formularioContacto.get('nombre') }
  get campoEmail() { return this.formularioContacto.get('email') }
  get campoAsunto() { return this.formularioContacto.get('asunto') }
  get campoDescripcion() { return this.formularioContacto.get('descripcion') }

  //Validaciones del formulario de contacto
  get nombreValido() { return this.campoNombre.valid && this.campoNombre.touched; }
  get nombreInvalido() { return this.campoNombre.invalid && this.campoNombre.touched; }

  get emailValido() { return this.campoEmail.valid && this.campoEmail.touched; }
  get emailInvalido() { return this.campoEmail.invalid && this.campoEmail.touched; }

  get asuntoValido() { return this.campoAsunto.valid && this.campoAsunto.touched; }
  get asuntoInvalido() { return this.campoAsunto.invalid && this.campoAsunto.touched; }

  get descripcionValido() { return this.campoDescripcion.valid && this.campoDescripcion.touched; }
  get descripcionInvalido() { return this.campoDescripcion.invalid && this.campoDescripcion.touched; }

}
