import { Component, inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormGroup,FormBuilder, ReactiveFormsModule } from '@angular/forms'
import { ServicioLoginService } from '../../servicio-login.service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule, isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  //Inicializamos dos variables, formLogin perteneciente al formulario de login y loginValidate para los mensajes de validacion del login de usuario
  formLogin:FormGroup;
  loginValidate:boolean=true;
  navegador: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  constructor (private servicio:ServicioLoginService, private fb:FormBuilder,private router:Router){
    this.formLogin= fb.group({
      usuario:[],
      contrasena:[]
    });

  }

  /*Funcion de inicio de sesion que llama a una funcion en el servicio, dicha funcion devuelve true/false en funcion de si el usuario y contraseña son validos
  si devulve true se redirije al usuario a /inicio, si es false se coloca la variable loginValidate en false y se muestra el mensaje de error.
  */
  iniciarSesion(){
    if(this.servicio.iniciarSesion(this.formLogin.value.usuario,this.formLogin.value.contrasena)){
      this.loginValidate=true;
      this.router.navigate(['/inicio']);
    }else {
      this.loginValidate=false;
    }
  }

  //Si el hay una sesion, redirigimos a /inicio
  ngOnInit(): void {
    if(this.navegador){
      if(sessionStorage.getItem("usuario")){
        this.router.navigate(['/inicio']);
      }
    }
  }

}
