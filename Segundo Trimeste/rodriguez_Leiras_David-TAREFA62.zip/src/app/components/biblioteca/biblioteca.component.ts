import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ListaReproduccion } from '../../../models/lista-reproduccion';
import { Cancion } from '../../../models/cancion';
import { Usuario } from '../../../models/usuario';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Album } from '../../../models/album';
import { Artista } from '../../../models/artista';

@Component({
  selector: 'app-biblioteca',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './biblioteca.component.html',
  styleUrl: './biblioteca.component.css'
})
export class BibliotecaComponent implements OnInit {
  //Nos traemos desde el componente "inicio" un array de listas y de canciones, pertenecientes al usuario con sesion iniciada, junto con el objeto de dicho usuario.
  @Input() listas:ListaReproduccion[];
  @Input() canciones:Cancion[];
  @Input() usuario:Usuario;
  @Input() albumes:Album[];
  @Input() artista:Artista;

  
  formLista:FormGroup;//Formulario de creacion de listas nueva
  nuevaLista:boolean=false;//Booleano que usamos para desplegar/ocultar el formulario de creacion de lista


  constructor(private fb:FormBuilder){ }

  ngOnInit(): void {
    this.formLista=this.fb.group({
      nombreLista:['',[Validators.required]]
    }) 
  }
  
  @Output() borrarLista=new EventEmitter<number>;//Esto enviara el id de la lista al componente padre para eliminar la lista de este usuario.
  @Output() enviarLista=new EventEmitter<string>;//Este Output envia el nombre de la lista a crear.
  @Output() enviarSeleccion= new EventEmitter<number>;//Este output envia el id de la lista de reproduccion que hemos seleccionado para ver.
  @Output() nuevoAlbumEmit=new EventEmitter<boolean>;
  listaSeleccionada:number;//Guardamos el id de la lista seleccionada para ver

  //Funcion que emite el evento desde "borrarLista" al componente madre para que en este se trate la informacion y se elimine la Lista de reproduccion.
  eliminarListaUsuario(id:number){
    this.borrarLista.emit(id);
  }

  //funcion para mostrar o esconder el form de creacion de nueva lista
  mostrarForm(){
    if(this.nuevaLista){
      this.nuevaLista=false;
    }else {
      this.nuevaLista=true;
    }
  }
  //funcion para esconder el form de creacion de nueva lista, usada por el boton de "cancelar" dentro de form.
  esconderForm(){
    this.nuevaLista=false;
  }

  //Funcion que emite el evento desde "enviarLista" al componente madre para que en este se trate la informacion y se cree la nueva Lista de reproduccion.
  //una vez enviada el formulario se resetea y se oculta.
  crearLista(){
    if(this.formLista.get('nombreLista').value){
      this.enviarLista.emit(this.formLista.get('nombreLista').value);
      this.formLista.reset();
      this.nuevaLista=false;
    }
  }

  //Funcion que emite el evento desde "enviarSeleccion" para desplegar el componente  lista-reproduccion mostrando la informacion referente
  //al id de lista de reproduccion enviado.
  seleccionarLista(id:number){
    this.listaSeleccionada=id;
    this.enviarSeleccion.emit(id);
  }

  nuevoAlbum(){
    this.nuevoAlbumEmit.emit(true);
  }
}
