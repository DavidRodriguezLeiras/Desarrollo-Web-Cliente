import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Artista } from '../../../models/artista';
import { Cancion } from '../../../models/cancion';
import { CommonModule } from '@angular/common';
import { ListaReproduccion } from '../../../models/lista-reproduccion';

@Component({
  selector: 'app-vista-artista',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './vista-artista.component.html',
  styleUrl: './vista-artista.component.css'
})
export class VistaArtistaComponent {
  @Input() artistaSeleccionado:Artista;
  @Input() cancionesArtista:Cancion[];
  @Input() listasReproduccion:ListaReproduccion[];
  @Output() listaAnadir= new EventEmitter<[number,number]>
  @ViewChild('listaAnadir') lista!:ElementRef;

  formAnadirCancion:number|null;

  //Muestro el form en la cancion con id coincidente o si ya esta mostrando uno, devuelvo el valor a nulo para asi dejar de mostrarlo
  mostrarForm(idCancion:number){
    if(!this.formAnadirCancion){
      this.formAnadirCancion=idCancion;
    }else {
      this.formAnadirCancion=null;
    }
  }
  //Escondo el form haciendo que la variable formAnadirCancion quede en null.
  esconderForm(){
    this.formAnadirCancion=null;
  }

  //Emito el evento desde listaAnadir pasandole el id de la Cancion y el id de la lista de reproduccion, esta informacion sera recogida por el
  //componente madre y la informacion sera procesada para añadir la cancion a esa lista.
  anadirCancion(idCancion:number){
    if(this.lista.nativeElement.value){
      this.listaAnadir.emit([idCancion,this.lista.nativeElement.value]);
    }
  }
}
