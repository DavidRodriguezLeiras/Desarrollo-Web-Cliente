import { Component } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { RouterLink, RouterLinkActive } from '@angular/router';
import { HeaderComponent } from "../header/header.component";

@Component({
  selector: 'app-planes',
  standalone: true,
  imports: [FooterComponent,HeaderComponent],
  templateUrl: './planes.component.html',
  styleUrl: './planes.component.css'
})
export class PlanesComponent {

}
