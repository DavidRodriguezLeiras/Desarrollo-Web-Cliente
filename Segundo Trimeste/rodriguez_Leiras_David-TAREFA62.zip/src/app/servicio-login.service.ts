import { inject, Injectable, OnInit, PLATFORM_ID } from '@angular/core';
import { Usuario } from '../models/usuario';
import * as datos from "../../public/datos/datos.json";
import { isPlatformBrowser } from '@angular/common';
import { GestorDatosService } from './gestor-datos.service';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServicioLoginService{
  usuarios:Usuario[];
  usuarios$:BehaviorSubject<Usuario[]>;
  usuarioSesion:Usuario|null;

  //Comprobamos que la aplicacion esta ejecutandose en el navegador.
  navegador: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  constructor(private servicio:GestorDatosService, private router:Router) {
    
    if(this.navegador){
      //Compruebo si localStorage tiene usuarios guardados, si no los tiene extraigo los datos del JSON
      if(!localStorage.getItem('usuarios')){
        let usuariosJson= datos.usuarios.map((user) => new Usuario(user.id, user.nombreUsuario, user.nombre, user.apellidos, user.email,
        user.contrasena,user.rol, user.planVibe, user.idArtista, user.idListasReproduccion));
        localStorage.setItem("usuarios",JSON.stringify(usuariosJson));
        this.usuarios=usuariosJson;
      //Si localStorage tiene usuarios, entonces mapeo cada usuario en el array de usuarios.
      }else {
        this.usuarios=JSON.parse(localStorage.getItem('usuarios')).map((user:Usuario) => new Usuario(user._id, user._nombreUsuario,
        user._nombre, user._apellidos, user._email,user._contrasena,user._rol, user._planVibe, user._idArtista, user._idListasReproduccion));
      }
      this.usuarios$=new BehaviorSubject(this.usuarios);
      //Comprobamos si hay un usuario registrado en sessionStorage, si lo hay, guardamos el objeto usuario de nuestro array de usuarios en
      //usuarioSesion y actualizamos el usuario en el servicio de gestorDatos 'renovando' la sesion cuando recargamos la página.
      if(sessionStorage.getItem("usuario")){
        let usuarioStorage= JSON.parse(sessionStorage.getItem("usuario"));
        this.usuarioSesion= new Usuario(usuarioStorage._id,usuarioStorage._nombreUsuario,usuarioStorage._nombre,usuarioStorage._apellidos,
          usuarioStorage._email,usuarioStorage._contrasena,usuarioStorage._rol,usuarioStorage._planVibe,usuarioStorage._idArtista,
          usuarioStorage._idListasReproduccion);
        this.servicio.usuarioIniciado(this.usuarioSesion);
      }
    }
  }

  iniciarSesion(usuario:string,contrasena:string):boolean{
    for(let user of this.usuarios){
      if(user.nombreUsuario == usuario && user.contrasena == contrasena){
        if(this.navegador){
          this.servicio.usuarioIniciado(user);
          sessionStorage.setItem("usuario",JSON.stringify(user));
          return true;
        }
      }
    };
    return false;
  }

  cerrarSesion(){
    this.usuarioSesion = null;
    if(this.navegador){
      sessionStorage.removeItem("usuario");
    }
    this.servicio.usuarioCerrado();
    this.router.createUrlTree(['/portada']);
  }

  subscribirUsuarios(){
    return this.usuarios$.asObservable();
  }

  registrarUsuario(usuario:Usuario){
    this.usuarios.push(usuario);
    if(this.navegador){
      //Guardo los usuarios en localStorage actualizando el nuevo usuario.
      localStorage.setItem("usuarios",JSON.stringify(this.usuarios));
    }
    //Actualizo la informacion para los subscriptores.
    this.usuarios$.next(this.usuarios);
  }

  modificarUsuario(usuario:Usuario) {
    let index= this.usuarios.findIndex((user) => user.id == usuario.id);
    this.usuarios[index]=usuario;
    if(this.navegador){
      //Guardo los usuarios en localStorage actualizando el nuevo usuario.
      localStorage.setItem("usuarios",JSON.stringify(this.usuarios));
    }
    //Actualizo la informacion para los subscriptores.
    this.usuarios$.next(this.usuarios);
  }

  borrarUsuario(id:number){
    this.usuarios=this.usuarios.filter((idusuario => idusuario.id != id ));
    if(this.navegador){
      //Guardo los usuarios en localStorage actualizando el nuevo usuario.
      localStorage.setItem("usuarios",JSON.stringify(this.usuarios));
    }
    this.usuarios$.next(this.usuarios);
  }

}
