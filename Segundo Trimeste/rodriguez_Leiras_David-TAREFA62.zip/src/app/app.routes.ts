import { Routes } from '@angular/router';
import { LandingComponent } from './components/landing/landing.component';
import { LoginComponent } from './components/login/login.component';
import { RegistroComponent } from './components/registro/registro.component';
import { PerfilComponent } from './components/perfil/perfil.component';
import { InicioComponent } from './components/inicio/inicio.component';
import { AvisoLegalComponent } from './components/aviso-legal/aviso-legal.component';
import { SobreNosotrosComponent } from './components/sobre-nosotros/sobre-nosotros.component';
import { MapaWebComponent } from './components/mapa-web/mapa-web.component';
import { PoliticaPrivacidadComponent } from './components/politica-privacidad/politica-privacidad.component';
import { PlanesComponent } from './components/planes/planes.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { sesionGuard } from './guards/sesion.guard';
import { AdministrarComponent } from './components/administrar/administrar.component';
import { administradorGuard } from './guards/administrador.guard';
import { EditarArtistaComponent } from './components/editar-artista/editar-artista.component';

export const routes: Routes = [
    { path:'', redirectTo:'/portada', pathMatch:'full'},
    { path: 'portada', title:'Vibe - Entrada', component:LandingComponent},
    { path: 'login', title:'Vibe - login',component:LoginComponent},
    { path: 'registro', title:'Registro - Vibe', component:RegistroComponent},
    { path: 'perfil', title: 'Vibe - Perfil',component:PerfilComponent , canActivate:[sesionGuard]},
    { path: 'inicio', title: 'Vibe - Inicio', component:InicioComponent, canActivate:[sesionGuard]},
    { path: 'aviso-legal', title: 'Vibe - Aviso Legal', component:AvisoLegalComponent},
    { path: 'sobre-nosotros', title: 'Vibe - Sobre Nostros', component:SobreNosotrosComponent},
    { path: 'mapa-web', title: 'Vibe - Mapa Web', component:MapaWebComponent},
    { path: 'privacidad', title: 'Vibe - Politicas Privacidad', component:PoliticaPrivacidadComponent},
    { path: 'planes', title: 'Vibe - Planes', component:PlanesComponent},
    { path: 'contacto', title: 'Vibe - Contacto', component:ContactoComponent},
    { path: 'administrar', title: 'Vibe - Administrar', component:AdministrarComponent,canActivate:[sesionGuard,administradorGuard]},
    { path: 'administrar',children:[
        {path:'editar-artista/:artista',title:'Editar Artista',component:EditarArtistaComponent ,canActivate:[administradorGuard]} // Esta ruta recibe un parametro artista
    ]}
];
