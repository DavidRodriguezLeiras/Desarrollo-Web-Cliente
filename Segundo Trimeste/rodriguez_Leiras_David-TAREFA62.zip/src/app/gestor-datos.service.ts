import { Injectable } from '@angular/core';
import { Artista } from '../models/artista';
import { Cancion } from '../models/cancion';
import { ListaReproduccion } from '../models/lista-reproduccion';
import { Usuario } from '../models/usuario';
import * as datos from "../../public/datos/datos.json";
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Album } from '../models/album';
import { Genero } from '../models/genero';

@Injectable({
  providedIn: 'root'
})
export class GestorDatosService {
  //Definimos cada tipo de objeto que necesitaremos 
  //Tambien definimos para cada uno un subject que emitira el array correspondiente para sus subscriptores
  artistas: Artista[];
  artistas$: BehaviorSubject<Artista[]>;

  canciones: Cancion[];
  canciones$: BehaviorSubject<Cancion[]>;

  listas: ListaReproduccion[];
  listas$: BehaviorSubject<ListaReproduccion[]>;

  albumes:Album[];
  albumes$:BehaviorSubject<Album[]>;

  generos:Genero[];
  generos$:BehaviorSubject<Genero[]>;

  //Este variable guarda el usuario con sesion iniciada
  usuario: Usuario;
  usuario$: BehaviorSubject<Usuario>;

  //Esta variable guarda el artista del usuario con sesion iniciada
  artista:Artista;
  artista$:BehaviorSubject<Artista>;

  constructor() {
    //Inicializamos cada subject y hacemos una carga de los datos desde el .json
    this.artistas = datos.artistas.map((artista) => new Artista(artista.id, artista.nombre, artista.idCanciones, artista.imagen,artista.idAlbumes,artista.idGeneros));
    this.artistas$ = new BehaviorSubject(this.artistas);
    
    this.canciones = datos.canciones.map((cancion) => new Cancion(cancion.id, cancion.titulo, cancion.idArtista, cancion.duracion,cancion.idGenero,cancion.pathCancion));
    this.canciones$ = new BehaviorSubject(this.canciones);

    this.albumes = datos.albumes.map((album) => new Album(album.id,album.nombreAlbum,album.descripcion,album.fechaSalida,album.idCanciones,album.pathImagen,album.idGeneros));
    this.albumes$= new BehaviorSubject(this.albumes);

    this.generos=datos.generos.map((genero)=> new Genero(genero.id,genero.nombre));
    this.generos$=new BehaviorSubject(this.generos);

    this.listas = datos.listasReproduccion.map((lista) => new ListaReproduccion(lista.id, lista.nombre, lista.idCanciones, lista.pathImagen));
    this.listas$ = new BehaviorSubject(this.listas);
    
    this.usuario$=new BehaviorSubject(this.usuario);
    this.artista$=new BehaviorSubject(this.artista);

  }

  //Devolvemos un observable en funcion del string que le pasemos.
  subscribirse$(tipo: string):Observable<any>{
    switch (tipo) {
      case 'artistas':
        return this.artistas$.asObservable();
        break;
      case 'canciones':
        return this.canciones$.asObservable();
        break;
      case 'listas':
        return this.listas$.asObservable();
        break;
      case 'albumes':
        return this.albumes$.asObservable();
        break;
      case 'generos':
        return this.generos$.asObservable();
      case 'usuario':
        return this.usuario$.asObservable();
        break;
      case 'artista':
        return this.artista$.asObservable();
      default:
        return of(null);
        break;
    }
  }

  /* Funcion que permite manejar las listas de reproduccion del objeto Usuario, podemos de momento añadir y borrar id de lista de reproduccion*/
  manejarListasUsuario(idUsuario: number, idLista: number, operacion: string) {
    if (operacion == "add") {
      this.usuario.idListasReproduccion.push(idLista);
      this.usuario$.next(this.usuario);
    } else if (operacion == "delete") {
      this.usuario.idListasReproduccion=this.usuario.idListasReproduccion.filter((id: number) => id != idLista);
      this.usuario$.next(this.usuario);
    }
  }
  /* Funcion que permite manejar las canciones en las listas de reproduccion, podemos de momento añadir y borrar de las lista de reproduccion*/
  manejarCancionesLista(idCancion: number, idLista: number, operacion: string) {
    let arrLista = this.listas;
    if (operacion == "add") {
      for (let indice = 0; indice < arrLista.length; indice++) {
        if (arrLista[indice].id == idLista) {
          arrLista[indice].anadirCancion(idCancion);
        }
      }
    } else if (operacion == "delete") {
      for (let indice = 0; indice < arrLista.length; indice++) {
        if (arrLista[indice].id == idLista) {
          arrLista[indice].eliminarCancion(idCancion);
        }
      }
    }
  }

  /* Funcion que me permite eliminar listas de reproduccion */
  crearLista(nombreLista: string) {
    let arrListas = this.listas;
    arrListas.push(new ListaReproduccion(arrListas.length + 1, nombreLista, [],''));
  }

  //Llamo a este metodo desde el servicio de login, para tener en el gestor de datos el usuario con sesion
  //y poder operar sobre el mismo, con usuarioIniciado() inicio la sesion y actualizo para todos los suscriptores y con usuario cerrado cierro la sesion.
  usuarioIniciado(usuario:Usuario){
    this.usuario=usuario;
    this.usuario$.next(usuario);
    this.artista= this.artistas.find(artista=> this.usuario.idArtista == artista.id);
    this.artista$.next(this.artista);
  }

  usuarioCerrado(){
    this.usuario=null;
    this.usuario$.next(this.usuario);
    this.artista=null;
    this.artista$.next(this.artista);
  }

  modificarArtista(artista:Artista){
    this.artistas=this.artistas.filter(artistaBuscar=> artistaBuscar.id != artista.id);
    this.artistas.push(artista);
    this.artistas$.next(this.artistas);
    if(this.artista.id==artista.id){
      this.artista=artista;
      this.artista$.next(artista);
    }
  }

  anadirAlbum(album:Album){
    //Añadimos el album nuevo al array de albumes y al array de id de albumes del artista con sesion iniciada
    this.albumes.push(album);
    this.artistas.find(artistaBuscar=>artistaBuscar.id==this.artista.id).idAlbumes.push(album.id);

    //actualizamos la información para los suscriptores
    this.artistas$.next(this.artistas);
    this.albumes$.next(this.albumes);
  }
}
