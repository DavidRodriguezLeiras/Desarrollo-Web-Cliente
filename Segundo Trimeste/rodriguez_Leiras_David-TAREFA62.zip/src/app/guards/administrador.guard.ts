import { isPlatformBrowser } from '@angular/common';
import { inject, PLATFORM_ID } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Usuario } from '../../models/usuario';

export const administradorGuard: CanActivateFn = (route, state) => {
  let router =inject(Router);//Inyectamos el Router(Singleton) 
  let usuario:Usuario = null;
    if(isPlatformBrowser(inject(PLATFORM_ID))) {
      usuario = JSON.parse(sessionStorage.getItem("usuario")); //Recuperamos el valor del usuario actual desde session storage
    }
    if(usuario._rol == 'admin'){
      return true;
    }else {
      router.navigate(['/inicio']);
      return false;
    }
};
