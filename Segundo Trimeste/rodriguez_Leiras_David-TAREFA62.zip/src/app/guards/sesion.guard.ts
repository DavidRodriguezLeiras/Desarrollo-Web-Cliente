import { isPlatformBrowser } from '@angular/common';
import { inject, PLATFORM_ID } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const sesionGuard: CanActivateFn = (route, state) => {
  let router =inject(Router);//Inyectamos el Router(Singleton) 
  let usuario = null;
  let platformId=inject(PLATFORM_ID);

  if(isPlatformBrowser(platformId)) {
    if(sessionStorage.getItem("usuario")){
      usuario = sessionStorage.getItem("usuario"); //Recuperamos el valor del usuario actual desde session storage
    }
  }
  if(usuario){
    let rutaActiva = state.url;
    if(rutaActiva == '/login' || rutaActiva == '/registro' ){
      router.navigate(['/inicio']);
      return false;
    }
    return true;
  }else {
    router.navigate(['/login']);
    return false;
  }
};
