Como usar la página:

Podemos iniciar sesion con lo siguientes usuarios/contraseña:
    davidrl:abc123.. //admin
    usuario:abc123..    //usuario normal
    administrador:abc123.. //admin

Aspectos generales de la aplicacion:
Añadí dos modelos nuevos , Genero y Album.
Se han actualizado casi todos los estilos de la pagina haciendo uso de Bulma (aun hay algunas vistas con los estilos viejos).

Dentro de /inicio podemos hacer lo siguiente:
    Acceder a home desde el boton con el logo de la casita
    Crear una lista de reproduccion nueva dando al "+" a la derecha de "Mis listas".
    Borrar la lista deseada pinchando sobre el cubo rojo a la derecha de su nombre.
    Pinchar sobre las listas de reproduccion para ver las canciones de las que dispone cada una.
    En el "+" a la derecha de Mis Álbumes podemos crear un  nuevo álbum.
    De momento los Albumes no tienen la vista creada, pero su logica es la misma que la de las Listas de reproduccion
    Podemos filtar todos los elementos de la vista de inicio-home con las etiquetas de los generos a la derecha de "Explora Vibe!"
    
Dentro de la vista de la lista de reproduccion podemos:
    Pinchar sobre el cubo rojo a la derecha de todo para borrar la cancion de la lista de reproduccion.
    Pinchar sobre el nombre del artista para desplegar la vista del Artista.

Dentro de la vista del artista podemos:
    Pinchar sobre el "+" a la derecha del todo para desplegar un formulario donde podremos añadir dicha cancion a la lista de reproduccion deseada.

Reproductor:
    Implementado el reproductor, este permite iniciar/parar musica, avanzar y retroceder pista, silenciar y subir y bajar el volumen y reproducir la musica
    Para no ocupar mucho espacio, he incluido las canciones de la Lista de reproduccion "Lista 3" , si pinchas en la imagen de la lista se empezará a reproducir la musica.

Guards,rutas hijas y rutas parametrizadas:
    En /administrar tengo un guard que solo permite acceder si el usuario de la sesion es administrador
    /administrar tiene una ruta hija /administrar/editar-artista/:parametro que recoje el id de artista a editar , podemos acceder a traves del GUI desde administrar pulsando en el boton de la lista de usuarios llamado "Editar Artista".

    